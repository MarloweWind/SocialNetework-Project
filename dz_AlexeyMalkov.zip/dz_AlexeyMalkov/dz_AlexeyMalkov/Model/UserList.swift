//
//  UserList.swift
//  dz_AlexeyMalkov
//
//  Created by Алексей Мальков on 14.05.2020.
//  Copyright © 2020 Alexey Malkov. All rights reserved.
//

import UIKit
import Foundation

struct UserList{
    var name: String
    var avatar: UIImage
    var userImage: UIImage
}
